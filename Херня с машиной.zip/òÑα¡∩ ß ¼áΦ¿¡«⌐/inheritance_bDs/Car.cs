﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance_bDs
{
    internal class Car : Transport
    {
        public int mileage { get; set; }
        public bool isTechInspPassed { get; set; }
    }
}
